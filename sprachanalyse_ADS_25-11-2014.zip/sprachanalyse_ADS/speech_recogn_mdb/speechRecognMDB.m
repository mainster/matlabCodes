%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% speechRecognMDB.m                                                      @@@MDB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main für ADS- Projekt: Sprachkommando
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PATHA = '/home/mainster/CODES_local/matlab_workspace/wavefiles/14_56_53/';
% PATHB = '/home/mainster/CODES_local/matlab_workspace/wavefiles/16_48_38/backup';
% PATHA = '/home/mainster/CODES_local/matlab_workspace/wavefiles/14_56_53/backup';
% PATHB = '/home/mainster/CODES_local/matlab_workspace/wavefiles/16_48_38/';
% 
PATHB = '/home/mainster/CODES_local/matlab_workspace/wavefiles/14_56_53/backup2/';

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nummer 1...9 
% sequenzen aus wave dateien lesen
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k=1:9
    CMD = 'audioread';
    speech{k}  = eval( strrep([CMD '([PATHB, ''waveout_%i.wav''])'], '%i', num2str(k)));
    CMD = 'audioinfo';
    fss(k)  = eval( strrep([CMD '([PATHB, ''waveout_%i.wav''])'], '%i', num2str(k)));
    
    if fss(k).TotalSamples ~= length(speech{k})
        warning(['file #' num2str(k) ', different sizes??'])
    end
    mp(k) = audioplayer(speech{k},fss(k).SampleRate);
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Referenzsignal bilden: payloadDetector liefert eine
% zugeschnittene Sequenz --> ref1 
% Die Payload wird durch den parameter minLvl bestimmt, bei z.B.
% minLvl='-25dB' werden vorne und hinten alle Abtastwerte
% abgeschnitten, bis die Amplitude zum Erste mal > -25dB groß
% ist. PREDELAY und POSTDELAY sind Integer werte, die von den
% erkannten Grenzen abgezogen bzw. drauaddiert werden.
%

disp(' ');
disp(timeDate(1));
disp(' ');
tic
delete('ymic.mat');

while 0
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sprachkommando einlesen (recCmd) oder aus wav laden (audioread)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MODE = 0;   % aufnahme über mic

fsGlob = 16000;

if MODE == 0
    if ~exist('ymic.mat','file')
        optmsg.Default = 'Yes';
        optmsg.Interpreter = 'none';
        
        for k=5:-1:1
            disp([num2str(k*.5) 's'])
            delayWait(0.5);
        end
%         choice = questdlg('Aufnahme starten','Rec','Yes','No',optmsg)
%         if strcmp(choice, 'No')
%             return;
%         end
        disp('call...')
        
        [ymic, mpCmd, opt] = recCmd(fsGlob, 2, 2); %play(mpCmd)
%        f33=figure(33);
%        plot(ymic)
        save('ymic.mat','ymic', 'mpCmd', 'opt');
    else
        load('ymic.mat');
    end
    y = ymic;
    fsCmd = opt{1};
end

if MODE == 1
    if ~exist('WAVESPATH_FILE','var')       % --> Keine pfadangabe per fkt.- parameter
        y = audioread([WAVESPATH, 'waveout_1.wav']);
        infoCmd = audioinfo([WAVESPATH, 'waveout_1.wav']);
    else
        y = audioread(WAVESPATH_FILE);
        infoCmd = audioinfo(WAVESPATH_FILE);
    end
    fsCmd = infoCmd.SampleRate;
end
%    y = y(round([0.4:1/fsCmd:1]*fsCmd),1);      % Anfang ausklammern
    y = 1/5 * y(:,1)/max(abs(y(:,1)));      % auf 0.2 normieren

    objCmd = {y(:,1), fsCmd};

return


end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
REF=1;
CMD=4;

objRef.info         = fss(REF);
objRef.wav.fs       = fss(REF).SampleRate;
objRef.wav.data     = speech{REF};

objCmd.info         = fss(CMD);
objCmd.wav.fs       = fss(CMD).SampleRate;
objCmd.wav.data     = speech{CMD};


objRef.payload.data = payloadDetector(objRef.wav.data, '-25db',10,10);
objCmd.payload.data = syncSeqToRef(objCmd.wav.data,...
                                   objRef.payload.data, 'length', 'equal');
fprintf('\nSamples vor payload detector:\t%i\n', length(objRef.wav.data))
fprintf('Samples nach payload detector:\t%i\n\n',length(objRef.payload.data))

% objRef.payload.data = filter...
CLASSIFY = 1;

if CLASSIFY
    objRef.classify.data = classify2bit( objRef.payload.data' );
    objCmd.classify.data = classify2bit( objCmd.payload.data' );
    clref = objRef.classify.data;
    clcmd = objCmd.classify.data;
else
    clref = objRef.payload.data';
    clcmd = objCmd.payload.data';
end

%cmat = costMatFramer(clref([ADDR]), clcmd([ADDR2]), 25)
cmat = costMatFramer(clref, clcmd, 250)

for k=1:size(cmat,2)
    [ass{k}, cost(k)] = munkres(cmat{k});
    fprintf('Kosten #%i: %g\n',k,cost(k))
end

fprintf('\n%s\nSumme: %g\t\tLaufzeit: %.2gsek\n%s\n',ds,sum(cost(:)),toc,ds)

f80=figure(80); clf;
SUB = 210;

fs=objCmd.wav.fs;

for k=1:2
    s(k) = subplot(SUB+k);
end
subplot(s(1));
hold all;
plot([0:1:length(objRef.wav.data)-1]/fs, objRef.wav.data); 
plot([0:1:length(objCmd.wav.data)-1]/fs, objCmd.wav.data);
legend('Ref.wav.data','Cmd.wav.data');
hold off;
grid on;

subplot(s(2));
hold all;
plot([0:1:length(objRef.payload.data)-1]/fs, objRef.payload.data); 
plot([0:1:length(objCmd.payload.data)-1]/fs, objCmd.payload.data);
legend('Ref.payload.data','Cmd.payload.data');
grid on;
hold off;
 


