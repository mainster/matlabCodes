  DVD Genie - blight@inmatrix.com
----------------------------------------------------------------------------

 Introduction:
---------------
DVD Genie allows you to modify the region code for popular software-based
DVD Players such as Software Cinemaster, PowerDVD and WinDVD (among a few).
It also allows you to tweak these programs with undocumented features to
better fit your system.

DVD Genie will also allow you to select which program runs when a DVD Disc
is inserted into the drive and contains support for fullscreen Zooming on
widescreen movies with certain players.


 License:
----------
DVD Genie is free for non-commercial use,
read tlicense.txt for more information.


 Documentation:
----------------
DVD Genie's full documentation is kept on-line.  You can access
it by pressing on the "Online Help" button within DVD Genie, or
by going to this link:
http://www.inmatrix.com/genie


 More information:
-------------------
For the latest version and information,
visit the DVD Infomatrix home page at:
http://www.inmatrix.com

The all-important all-answering PCDVD-FAQ:
http://faq.inmatrix.com

The DVD Tips & Tricks page:
http://tips.inmatrix.com

And the news page at:
http://news.inmatrix.com

Also, visit the DVD Genie discussion board at:
http://forum.inmatrix.com



Also, come visit the folks on efnet #pcdvd channel.
