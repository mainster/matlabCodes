MP3 CD Organizer 2.7
Copyright(c) 2000 Peter Logarn
Release Date: 2000-07-19

E-mail: logge@hem.passagen.se
Homepage: http://hem.passagen.se/logge

Description:   Mp3 CD Organizer helps you to get all your mp3 files
               organized. Once the program has scanned your CD's and
               harddrive(s) you will always know where to find a song.
               It has powerful functions to search through the
               database. Organizer also frontends Winamp for easy
               playback of the songs that you have put on the playlist.
               To make your own favorite list of songs for fast
               playback later, Organizer can write playlist files,
               save and edit ID3 tags, as well as
               create HTML documents with your list of songs.

Legal Rights:  This program is freeware. If you like this program or
               find any bugs feel free to send an e-mail.
               It's always fun to receive mail!

Disclaimer:    You are using this software entirely at your own risk!
               This program may NOT be used to handle illegal music!

Coding:        Peter Logarn
Design:        Peter Logarn (Well, I'm a technologist not an artist)
Graphic:       Georgiana Gruia (My Girlfriend)
Assistants:    Berit Carlsson, Carl-Johan Sj�berg and others.
Beta Testers:  Georgiana Gruia, Linus Magnusson,
               David Tj�llskog, Stefan Jonasson.

To get online help, please visit the homepage!

Description of the different buttons in the program:

Player
Controls       - These are buttons to control Winamp.

Update Winamp  - Sends the songs in the playlist to Winamp.
                 To overcome the problem with having songs on different
                 CD's, select "copy to tempdir" in options, and the
                 music on the CD's will be copied to the harddrive.

Copy           - Copies the songs in the playlist to a directory.

New            - Adds a new CD or a Directory to the database. All
                 subdirectories will be scanned if selected in options.

Delete         - Removes a session from the database.

Playlist       - Writes the files you have chosen to a playlist
                 file, M3U. If you later double-click on this file,
                 the mp3's listed in it will be played in Winamp.

HTML           - Creates an HTML document with the list of your files.

Options        - Brings up the options dialog.

Random         - Randomly adds songs to the library.

Lyrics         - Displays the lyrics for the selected song.

Preview        - Plays the selected song in the library.

Search         - Searches for the files matching your specified
                 criteria. You can drag & drop information from
                 'ID3 Tags found' to these fields.

Quick menu     - A quick-menu will appear when clicking the right
                 mouse button.

Save           - Saves ID3 info in the mp3 file. If the file is
                 on a read-only media, the changes are made in the
                 database only.

Multisave      - Saves the artist, album, year and genre to a
                 group of songs selected in the library.

Session List   - Click a session in the list to display its contents
                 in the library. Double-click a session to update it.

Description for Options:

General:

Search
subdirectories - Searches all subdirectories when adding files.

Copy to
tempdir        - Copies the files to a tempdir if they are on CD's.
                 Then they will be played from there.
Case sensitive
search         - Differs between small letters, and capital letters
                 in the search.

Winamp:

Find Winamp    - Searches for Winamp on your harddrive. You can
                 also choose to do this manually.

Continues
playback       - the currently played song wont be interrupted
                 when pressing 'Update Winamp'.

Formatting:

Don't use ID3
tags           - If selected, Organizer will ignore any ID3
                 information stored in each mp3 file (ID3 is a
                 standard of storing information about artist,
                 title, album and more, in the mp3 file).
                 Otherwise, ID3 tags will always be used before the
                 operation 'Filename formatting'.
Filename
Formatting     - If your files have a name convention, such as
                 'artist-title.mp3', Organizer can use
                 that for displaying info about the song.
                 Just type how your filenames are structured
                 in the edit field.
                 Ex. %1 - %2 _ %3 means your files should be
                 like this: 'artist-title_album.mp3'.

Use folder as  - This option lets you choose if the name of the
                 folder, where the file is stored, should be used
                 to represent the artist, or the album, or if it
                 should not be used at all.
                 As with 'Filename formatting', this option will be
                 overridden if there is ID3 information in the file.

Library:

Lets you choose which info to show in the library.

Internal Player:

Contains volume control and equlizer for the internal player.


The other functions should be obvious!

Instructions for getting the program to run:

Short Instructions:

Simply unzip all the files in a directory of your own choice then
double-click organizer.exe to start the program.
You need to have the newest Mfc42.dll and ODBC support for MS Access
installed.
The last-mentioned is included in the MS Office 97/2000 installation.

Long Instructions:

This program is compiled with Visual C++ 6.0 and requires the newest
Mfc42.dll. This file MUST be in the system in order for the program
to work. If not found, the following error message will be returned:
"The ORGANIZER.EXE file is linked to missing export MFC42.DLL:6880."
The file can be downloaded from MS or from my homepage. It should
then be placed in the windows\system directory, or in the Organizer
folder.

This program uses Winamp mp3 player, which must be present in the
system. Winamp is shareware and can be downloaded from www.winamp.com.
Winamp is the only player that will work.

In order to get MP3 CD Organizer to run properly, there are some
things that you need to have on your computer. Since this program
uses a MS Access 97 database, you will need to have ODBC with
support for Access 97 databases installed. Probably, you already
have this if you are running Office 97/2000. These drivers can also
be downloaded from the MS site. www.microsoft.com/data/odbc