1. DVD Profiler is simply the best way to catalog your DVD addiction!
2. To install DVD Profiler, simply run the setup.exe file included
   in this archive.
3. DVD Profiler is Freeware, but there is also a premium version available
   which adds more features (this version is NOT crippled in any way).
4. This program can be distributed freely as long as its contents are not
   in any way modified.  Users of this program must register with us at
   http://www.dvdprofiler.com
5. Contact InterVocative Software, LLC regarding this software at
   dvdprofiler@dvdprofiler.com or visit the website at
   http://www.dvdprofiler.com

dvdpr110.zip has replaced dvdpr102.zip.

--

New Features in 1.1.0
 * Reports
  - Added user review
  - Added true conditionals
  - Added Owned/Ordered/Wishlist
  - Added average SRP, average price paid
  - Added date purchased
  - Implemented image preview
  - Added pg-up, pg-down, ctrl-home, ctrl-end, +, - to report preview
  - Added "jump to page" option in report preview
 * Skins
  - Added user review
  - Implemented image preview
  - Added Owned/Ordered/Wishlist
  - Added collection number to skins
  - Added purchase price, place, date to skins
  - Added UPC
 * Improved speed of Add DVD interface dramatically
 * Increased maximum size of DVD Title and Desc ('Special Edition', etc).
 * Added filters for Genre and MPAA rating in Add DVD interface
 * Profile contribution no longer uses email - is now a web-based system
 * Option to include price list download when updating collection listing
 * Favorite retailer selection
  - Shows favorite retailer first in price listings
  - Shows "Click to buy" with price when viewing wishlist
 * Added support for 6.1 and 7.1 audio
 * Option to perform high-quality image resizing (slower, but way cleaner!)
 * Option to permanently skip a particular profile update
 * Added check for failure on downloads, prompt to continue if failed
 * Interface change allows loaning DVDs, viewing statuses while viewing with a
   custom skin
 * Changed default in Profile Refresh to overwrite existing images when
   changed
 * DVD Profiler now remembers display/sort options for All, Owned, Ordered,
   Wishlist independently
 * Now remembers last export format
 * Added thank you page for premium registrations, which automatically
   upgrades program options
 * Added automatic prompt to temporarily unlock images when selecting to edit
 * Added lock indicator to large image display
 * Added parental control indicator when parental control is on
 * Added display of filename in skin/report selection windows
 * *New Premium Upgrade Feature* - Virtually unlimited online collection sizes
   (collection size in DVD Profiler remains unlimited for all users)
 * Added filter by region
 * Added option to permanently skip a particular profile update
 * Download list saving
  - Enter list of DVDs to add, then save the list for later download
  - If an error occurs in the middle of a download list, DVD Profiler
    auto-saves the download list to continue at that point
 * New feature to automatically reassign collection numbers
  - Reassign all at once, or do a partial reassignment
  - Optionally eliminate gaps, duplicates, and assign where blank
  - Order by purchase date or release date
  - Specify number ranges to leave alone
 * Enhanced Ad component
  - Animated image masks (for cooler ads that take less time to download)
  - Region-specific ads
  - Ads targeted to your taste in DVDs (done without sending any information
    to IVS or anyone else!)
  - Moved ads to right side to make more room for the DVD listing
  - Changed ad size to industry standard
 * Added display for number of DVDs hidden by parental control
 * Improved clarity in interface for adding new DVDs not in the online
   database
 * Improved download performance for some users (@Home, etc.)
 * Backup/Restore
  - Added prompt to overwrite existing backup file
  - Added backup date/time, displayed when restoring
  - Now remembers last backup location and filename
 * Added filter for "Not Currently Loaned"
 * After download complete, scroll is now available
 * Added optional anonymous contribution of profiles
  - Note: This is anonymous to other users, but not to IVS

Bug Fixes in 1.1.0
 * Corrected Access Violation with some regional settings when selecting
   date range in Add DVD window
 * Corrected role assignment to existing actors
 * Corrected import/display of image last modified date
 * Corrected Add window occasionally refusing to close
 * Corrected calculation of file size in download progress
 * Corrected issue specifying audio track #7
 * Corrected issue displaying audio track #8 in reports
 * Corrected profile comparison not working from button
 * Corrected profile comparison not working from main menu
 * Eliminated "backup complete" message when backup failed to start
 * Corrected last edited date not being backed up
 * Corrected "Dataset not in edit or insert mode" when click assign actors,
   cancel, assign director, add director, ok
 * Corrected check for existing actor when editing another actor name
 * Added reset of download timestamps after changing parental control
 * Corrected title search for titles containing ' characters
 * Corrected word wrap bug which caused some lines to indent slightly
 * Corrected loss of program focus after running reports
 * Corrected full frame showing as pan&scan in images
 * Increased image load thread priority (now much faster for those running
   Seti@Home in the background!)
 * If select to restore images only, don't clear the existing collection
 * DVDs edited locally now force full upload to online collection
 * Purchase date no longer set when adding to wishlist

New Features in 1.0.2
 * Changed profile database backup to include images by default.
 * Add Loaned To, Loan Due fields for reports.

Bug Fixes in 1.0.2
 * After refreshing online list, current DVD no longer shows all actors in
   the system.
 * Blank director entries are no longer created during refresh or restore of
   profiles.
 * When assigning roles or actors, and canceling, does not disrupt actor
   display any more.
 * When clicking on director, will now show assignments for both first
   and second directors.
 * Slow and incorrect behavior when adding actors with a filtered actor list
   no longer occurs.
 * Locks are now being restored correctly after back up and restore.
 * List index out of bounds when comparing profiles where the newer profile
   had fewer actors has been eliminated.
 * Now able to edit notes when adding a DVD. 

General Features List
*  Keep Track of Your Entire DVD Collection	
 DVD Profiler can manage any size DVD collection.  Extensive data collection,
 filtering and reporting features specific to DVD, and unique to DVD Profiler.

*  Internet Connected for Sharing Profiles
 DVD Profiler Connects to the Online DVD Database at IVS.  IVS maintains a
 constantly growing database of DVDs.  The database is built by you - the users
 of the program.  Each DVD is entered once, by one user, and shared with all
 users.  Find an error?  Correct it and automatically share your correction
 with everyone.  Since the database is user-built, it will keep growing and
 refining until it is the most complete and accurate repository of DVDs in the
 world.

*  One-step DVD Entry
 For DVDs already in our database, entry into your collection is a one-step
 deal.  Enter the UPC from the DVD case, and DVD Profiler will retrieve the
 entire DVD Profile from our online database.  If you have a DVD-ROM drive,
 it's even easier.  Put the DVD in the drive and DVD Profiler asks if you
 would like to add it to your collection!

*  Track Complete DVD Information
 DVD Profiler stores a wide variety of data on the DVDs in your collection:
Title   Director           Production Year  Audio Formats  Running Time
UPC     Actor Names/Roles  MPAA Rating      Video Formats  Disc Extras
Studio  Release Date       Case Type        Disc Formats   Front & Back Pics
Genre   Purchase Date      Region           Overview       ...and much more!
 
*  Extensive Filter and Search
 How many DVDs in your collection star Bruce Willis, feature Widescreen and
 Pan & Scan versions, and is rated PG-13?  Which ones have the phrase "epic
 adventure" in the overview?  DVD Profiler supports any combination of filters
 and searches.  Filter for display or report printing through the same
 interface.

*  Parental Control
 Not all DVDs are G-rated, and some of our users may want to keep some of
 their collection from prying eyes.  For these reasons, DVD Profiler has
 complete parental control features which allow users to hide DVDs based on
 customizable criteria.  The default password for accessing the parental
 controls is "ACKNOWLEDGEMENT".  This password can be changed, and parental
 control can be disabled at the users preference.

*  'Wishlist' and 'Ordered' Collections
 - Keep track of announced DVDs you want in your Wishlist.
 - Move DVDs to your Ordered listing when an order is made.
 - When your new DVD is received, move it to your Owned collection.
 - Intelligent prompts ask for the applicable info at each step.

*  DVD Price-Finder
 Now that you can track your wishlist inside DVD Profiler, what better place to
 find the best prices?
  - Full price listings (updated daily) from several major online DVD retailers!
  - Search for prices on your entire Wishlist or just part of it!
  - Price search engine combines standard prices, sales, even shipping charges,
    for the most accurate comparisons!
  - New retailers are joining all the time! Online retailers who wish to join,
    send mail to admin@intervocative.com.
  - Purchase Wizard allows you to select retailers for each DVD and takes you to
    the site (and the specific DVD) of your choice.

*  Fully Customizable Reports
 - Create Free-form reports:
  - Use our built-in report designer to define your report layout.
  - Define headers, footers, page headers, page footers, and data layouts.
  - Create anything from a one-line-per-DVD listing to a full-page-per-DVD
    datafest!
  - No tedium required! Our built-in designer does the hard work for you -
    create a Warner-style data grid in a snap!
  - Include a multitude of data items... in different formats, styles, positions
    - you name it!
  - The new report display engine supports other paper formats (A4 included!).
  - Our new in-house report display engine is far more stable than the 3rd party
    tool used in previous versions - works great under Windows 2000!
  - DVD Profiler will ship with several unique custom reports.

*  Skins
 - Replace the DVD information pane with an HTML page
  - Use our built-in intelligent color-coded HTML editor, or an editor of your
    choosing.
  - Insert DVD Profiler tags to let the report engine know how and where to
    insert data.
  - Our built-in editor can insert our tags and attributes simply by selecting
    them from a list.
 - Design a completely new info pane with a customized version of the report
   designer.
 - DVD Profiler will ship with several unique custom skins.
