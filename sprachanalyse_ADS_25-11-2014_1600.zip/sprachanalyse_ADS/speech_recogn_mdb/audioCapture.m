%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% audioCapture.m                                                      @@@MDB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% funktion zum aufnehmen (mic) bzw. einlesen von offline-
% Sprachkommandos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [objOut] = audioCapture(SRC, varargin)

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sprachkommando einlesen (recCmd) oder aus wav laden (audioread)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MODE = 0;   % aufnahme über mic

fsGlob = 16000;

if MODE == 0
    if ~exist('ymic.mat','file')
        optmsg.Default = 'Yes';
        optmsg.Interpreter = 'none';
        
        for k=5:-1:1
            disp([num2str(k*.5) 's'])
            delayWait(0.5);
        end
%         choice = questdlg('Aufnahme starten','Rec','Yes','No',optmsg)
%         if strcmp(choice, 'No')
%             return;
%         end
        disp('call...')
        
        [ymic, mpCmd, opt] = recCmd(fsGlob, 2, 2); %play(mpCmd)
%        f33=figure(33);
%        plot(ymic)
        save('ymic.mat','ymic', 'mpCmd', 'opt');
    else
        load('ymic.mat');
    end
    y = ymic;
    fsCmd = opt{1};
end

if MODE == 1
    if ~exist('WAVESPATH_FILE','var')       % --> Keine pfadangabe per fkt.- parameter
        y = audioread([WAVESPATH, 'waveout_1.wav']);
        infoCmd = audioinfo([WAVESPATH, 'waveout_1.wav']);
    else
        y = audioread(WAVESPATH_FILE);
        infoCmd = audioinfo(WAVESPATH_FILE);
    end
    fsCmd = infoCmd.SampleRate;
end
%    y = y(round([0.4:1/fsCmd:1]*fsCmd),1);      % Anfang ausklammern
    y = 1/5 * y(:,1)/max(abs(y(:,1)));      % auf 0.2 normieren

    objCmd = {y(:,1), fsCmd};

return


objOut = -1;

end


%