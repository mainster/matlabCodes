%%%%% NT Klausur WS12-13
%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
delete(findall(0,'type','line'));

% Die Temperatur ist ein Zufallsprozess mit der Wahrscheinlichkeitsdichte
dtheta=0.001;
theta=-32:dtheta:32;

ft=-1/128*theta+1/8;
ft(1:32/dtheta)=zeros(1,32/dtheta);
ft(48/dtheta+1:end)=zeros(1,16/dtheta+1);

ftt(1,:)=theta;
ftt(2,:)=ft;

clf ('reset');
f1=figure(1);
SUB=120;

subplot(SUB+1);
plot(ftt(1,:),ftt(2,:));
grid on;
xlabel('theta / degC');
title('Wahrscheinlichkeitsdichte');

subplot(SUB+2);

%Fs = 32e3;   
%t = 0:1/Fs:2.96;
%x = cos(2*pi*t*1.24e3)+ cos(2*pi*t*10e3)+ randn(size(t));
Fs=1/dtheta;
nfft = 2^nextpow2(length(ftt(2,:)));
Pxx = abs(fft(ftt(2,:),nfft)).^2/length(ftt(2,:))/Fs;

% Create a single-sided spectrum
Hpsd = dspdata.psd(Pxx(1:length(Pxx)/2),'Fs',Fs);  
%hold all;
plot(Hpsd.Data);
xlim([0 10])
%plot(log10(Hpsd.Data),'r');
hold off;