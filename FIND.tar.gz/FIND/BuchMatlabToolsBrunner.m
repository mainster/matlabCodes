%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Zum Buch: Matlab & Tools (U.Brunner)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%oldLines=findall(0,'type','line');    % Inhalte der letzten plots löschen, figure handle behalten
oldLines=findall(0,'type','figure');    % Inhalte der letzten plots löschen, figure handle behalten
delete(oldLines);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% S.328: Polplatzierung
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%










