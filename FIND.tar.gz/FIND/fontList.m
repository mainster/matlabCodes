%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot all available Fonts on a figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if exist('f99')==1;
    if ishghandle(f99');
        close(f99)
    end
    clear f99;
end

f99=figure('Name','myName','NumberTitle','off',...
    'units','normalized','outerposition',[0 0 1 1]);
clf

fontListv=listfonts;

text(0.25,0.25,'test');
delete(findall(f99,'type','text'));
childH=get(f99,'Children')
set(childH,'Visible','Off');

xp=0;
yp=1;
for i=1:length(fontListv)
    yp=yp-1/30;
    th=text(xp,yp,char(fontListv(i)));
    set(th,'FontSize',14,'FontName',char(fontListv(i)))
    if yp<=0
        yp=1;
        xp=xp+1/5;
    end
end

