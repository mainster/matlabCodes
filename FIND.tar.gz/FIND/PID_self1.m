% Postprocessing PID_self1.mdl
%
%

t=[0:length(out.signals.values)-1];
plot(t,out.signals.values)