%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Figure 3 %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f3=figure(3);
SUB=230;

subplot(SUB+1);
rlocus(q1*p1)
legend('q1*p1')
xlim([-22 3])
ylim([-10 10])
for i=1:length(phi)
    lh1(i)=line([rs 10],[rs rs],'LineStyle','-');
    rotate(lh1(i),[0 0 1],phi(i));
end


return


A=[-2 -2 4 -2]'

%  C= A(ia,:) and A = C(ic,:)

[C ia ic]=unique(A);
hc=histc(A,C)

% hc(1) mal den wert der bei C(1) drin steht
% hc(2) mal den wert der bei C(2) drin steht
str1=[]
for i=1:length(C)
    str1=[str1 sprintf('Der Wert %i ist %i mal in A vorhanden\n',C(i),hc(i))];
end

disp(str1)
