%Mashinen_Epsilon berechnen

eps1 =1;

while(1+eps1 >1)
    eps1=eps1/2;
end
epsBer = 2*eps1;