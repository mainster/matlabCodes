% Regelungstechnik LTI Systeme

% sys1 = tf(num,den) % transfer function
% sys2 = ss(a,b,c,d) % state space % Zustandsvariable

h=tf(1,[1 1]);
