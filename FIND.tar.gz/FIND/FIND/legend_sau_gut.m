aa=[0:0.33:20];
legend([strsplit(sprintf('a=%.2f:',aa),':')])