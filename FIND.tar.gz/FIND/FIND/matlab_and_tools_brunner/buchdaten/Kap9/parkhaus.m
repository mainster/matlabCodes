function [besetzt]=parkhaus(autos,plaetze)
if autos>=plaetze besetzt=1;
else besetzt=0;
end;
