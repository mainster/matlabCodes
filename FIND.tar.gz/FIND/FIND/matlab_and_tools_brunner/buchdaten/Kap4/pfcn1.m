% Programm (pfcn1.m) zur Parametrierung des Modells fcn_1.mdl

global y1  y2

y1 = 0;        % Anfangswerte der Funktionen der MATLAB Fcn-Bl�cke
y2 = 0;        % aus dem Modell
