function ode_test2
% Funktion ode_test2.m in der ein einfaches Feder-Masse-System
% mit ODE-Funktion gel�st wird

%------- Initialisierung des Systems
m = 0.2;                % Masse
r = 0.9;                % D�mpfungfaktor
D = 0.8;                % Federkonstante

% Anfangsbedingungen
x10 = 0.2;              % Weg
x20 = -0.2;             % Geschwindigkeit
x0 = [x10; x20];

%------- Aufruf des Solvers
[t,x] = ode45(@ableitung,[0, 20], x0, [], m, r, D);

% Darstellung der L�sung
figure(1);      clf;
plot(t,x);
title(['Weg und Geschwindigkeit f�r x0 = [',num2str(x10),'; ',...
        num2str(x20),']']);
xlabel('Zeit in s');        grid on;
legend('Weg x1','Geschwindigkeit x2');

%******************************************************
% Private Funktion, in der die Ableitungen berechnet werden
function ableit = ableitung(t, x, m, r, D)

ableit = [x(2); (-D/m)*x(1)+(-r/m)*x(2)*abs(x(2))];
