
%waitforbuttonpress

jDesktop = com.mathworks.mde.desk.MLDesktop.getInstance;
jDesktop.getMainFrame.setTitle('... Really a Soft Skill? ...');
