%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% processing GalvoPHD.mdl
% Blockschaltung eines Galvos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

findall(0,'type','line');    





[A,b,c,d]=linmod('GalvoPHD');









