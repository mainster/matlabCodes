% Programm (alqrd1.m) zur Parametrierung und 
% Durchf�hrung der Simulation einer Regelung mit
% diskretem LQR-Verfahren
% Benutzt die SIMULINK-Modelle: s_proz1.mdl, s_alqrd1.mdl und 
% alqrd2.mdl 
% 
% Testaufruf: alqrd1;

%------Ermittlung des Zustandsmodells
[A, B, C, D] = linmod('s_proz1');

T = [1 0 0 0; 0 0 0 1; 0 0 1 0; 0 1 0 0];
[A,B,C,D] = ss2ss(A,B,C,D,T);

Co = ctrb(A,B);
if rank(Co) ~= 4
    disp(' Das System ist nicht Steuerbar !!!');
    return;
end;

%------LQR-R�ckf�hrungsmatrix
%------Kosten der Abweichunge
Q = eye(4,4);		Q(1,1) = 100;
R = 1;
Ts = 0.25;		% Abtastperiode

[K, S, E] = lqrd(A,B,Q,R,Ts);

%------�berpr�fung der neuen Pole
eig(A-B*K)

%------Verhalten des Systems mit den neuen Polen
figure(1);		clf;
t_final= 15;	
x0 = [5, 0, 0, 0];	% Anfnagsbedingung
min_step = 0.1;		max_step = min_step;

my_opt = simset('InitialStep', min_step, 'OutputVariables', 'ty');
[t,x,y] = sim('s_alqrd1', [0, t_final], my_opt);    % SIMULINK 2

subplot(211), plot(t, y(:,2:5));
title('Zustandsvariablen fuer x(0) = [ 5 0 0 0 ]');
xlabel('Zeit in s');	grid;
subplot(212), plot(t, y(:,6));
title('Steuersignal fuer x(0) = [ 5 0 0 0 ]');
xlabel('Zeit in s');	grid;

%------F�hrungsregelung 
k1 = K(1); 	k2 = K(2);	
k3 = K(3);	k4 = K(4);

%-----Bestimmung der F�hrungsmatrix
x_un = inv(A-B*K)*(-B*k1);

% x_un = x_un/x_un(1);		%-----Verfahren Nr. 1
% F = -B'*(A-B*K)*x_un/k1;
% F = 1/x_un(1);	      	%-----Verfahren Nr. 2
F = K*(x_un/x_un(1))/k1		%-----Verfahren Nr. 3

%------Verhalten des Regelungssystems
figure(2); 		clf;
min_step = 0.1;		max_step = min_step;
t_final = 15;

my_opt = simset('InitialStep', min_step, 'OutputVariables', 'ty');
[t,x,y] = sim('s_alqrd2', [0, t_final], my_opt);    % SIMULINK 2

subplot(211), plot(t, y(:,1));
title('Sprungantwort (Sprung bei 2,5 s)');
xlabel('Zeit in s');		grid;
La = axis;	axis([La(1), La(2), La(3), 1.2*La(4)]);
subplot(212), plot(t, y(:,2));
title('Prozess-Steuerung');	
xlabel('Zeit in s');		grid;

