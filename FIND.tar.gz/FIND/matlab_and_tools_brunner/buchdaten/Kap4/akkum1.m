function y1 = akkum1(x1)
% Akkumulator f�r das Modell fcn_1.mdl
% x1 = laufender Wert

global y1

y1 = y1 + x1;
