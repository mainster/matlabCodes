function fun = f(x,y)
%
%z=5.*cos(x)+x.^3-2.*x.^2-6.*x+10;
%fun=x.^2-2;
%fun=sin(x);
fun=real(sqrt(25-x.^2-y.^2));
end
