% Polyfit der Ordnung 1: Messreihe zB aus dem ohmschen gesetz, man wei? es
% liegt eine gerade zu grunde:

x=0: