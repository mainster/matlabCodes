Are=1;
Aim=1;
phideg=0; % [phi]=°
DCre=0;
DCim=0;

phi=phideg*pi/180;


fc=37;
fs=160;
Tc=1/fc;
Ts=1/fs;
n=256;

k=lcm(fc,fs);
tx=lcm(k,32);

t=[0:Ts:(tx-1)*Ts];  




s1=DCre+Are*cos(2*pi*fc*t) + i*(DCim+Aim*sin(2*pi*fc*t+phi));

s1=s1/max(imag(s1));

s1=s1*(2^15-1);

k=lcm(fc,fs)
kx=lcm(k,32)

mod(length(s1),32)
