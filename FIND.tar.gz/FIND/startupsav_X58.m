%STARTUPSAV   Startup file
%   Change the name of this file to STARTUP.M. The file 
%   is executed when MATLAB starts up, if it exists 
%   anywhere on the path.  In this example, the
%   MAT-file generated during quitting using FINISHSAV
%   is loaded into MATLAB during startup.

%   Copyright 1984-2000 The MathWorks, Inc. 
%   $Revision: 1.4 $  $Date: 2000/06/01 16:19:26 $

%load matlab.mat

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % exec shortcut 'cd CODES_local'
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% jDesktop = com.mathworks.mde.desk.MLDesktop.getInstance;
% jDesktop.getMainFrame.setTitle('... Really a Soft Skill? ...');
cd /home/mainster/CODES_local/matlab_workspace/


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set default text options
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set(0,  'DefaultAxesFontName','Swiss 721',...
        'DefaultAxesFontSize',12);

% set(0,  'DefaultTextFontName','Swiss 721',...
%         'DefaultTextFontSize',12);
%        'DefaultTextInterpreter','latex');


%run softSkill.m
